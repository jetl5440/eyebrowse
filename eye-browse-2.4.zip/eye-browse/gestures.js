// Decides when a gesture has happened. Everything here is plain logic fed with numbers and times,
// so it can be tested without a camera.

// Learns what the resting face looks like, so gestures are measured as a change from it.
// Feed it objects of numbers; afterwards `values` holds each one's average and `noise` how much each wobbled.
export class Baseline {
  constructor(durationMs, minSamples = 10) {
    this.durationMs = durationMs;
    this.minSamples = minSamples;
    this.values = {};
    this.noise = {};
    this.active = false;
  }

  start(now) {
    this.sum = {};
    this.squares = {};
    this.count = 0;
    this.endsAt = now + this.durationMs;
    this.active = true;
  }

  // Feed one reading. Returns true on the reading that completes the baseline.
  add(reading, now) {
    if (!this.active) return false;
    for (const [key, value] of Object.entries(reading)) {
      this.sum[key] = (this.sum[key] ?? 0) + value;
      this.squares[key] = (this.squares[key] ?? 0) + value * value;
    }
    this.count += 1;
    if (now < this.endsAt || this.count < this.minSamples) return false;
    for (const key of Object.keys(this.sum)) {
      const mean = this.sum[key] / this.count;
      this.values[key] = mean;
      this.noise[key] = Math.sqrt(Math.max(0, this.squares[key] / this.count - mean * mean));
    }
    this.active = false;
    return true;
  }
}

// Eyebrows: raise to go to the next video, furrow to go back.
export class BrowScroll {
  constructor({ holdMs = 150, cooldownMs = 1000, settleMs = 300 } = {}) {
    this.holdMs = holdMs;         // a gesture must be held this long, so a twitch doesn't scroll
    this.cooldownMs = cooldownMs; // after a scroll, wait this long, so one gesture is one scroll
    this.settleMs = settleMs;     // after a blink or a head shake, wait this long, because both move the brows
    this.reset();
  }

  reset() {
    this.upSince = 0;
    this.downSince = 0;
    this.blockedUntil = 0;
  }

  // Call instead of update() while the eyes are shut or the head is shaking.
  block(now) {
    this.upSince = this.downSince = 0;
    this.blockedUntil = Math.max(this.blockedUntil, now + this.settleMs);
  }

  // `up` and `down` are how far the brows have moved from rest. Returns "next", "prev" or null.
  update(up, down, limits, now) {
    if (now < this.blockedUntil) {
      this.upSince = this.downSince = 0;
      return null;
    }
    const raised = up > limits.up, furrowed = down > limits.down;
    this.upSince = raised ? (this.upSince || now) : 0;
    this.downSince = furrowed ? (this.downSince || now) : 0;

    let action = null;
    if (raised && now - this.upSince >= this.holdMs) action = "next";
    else if (furrowed && now - this.downSince >= this.holdMs) action = "prev";
    if (action) {
      this.upSince = this.downSince = 0;
      this.blockedUntil = now + this.cooldownMs;
    }
    return action;
  }
}

// Shaking the head side to side likes. A shake means the head passes `need` to one side, then to the other
// side, then back again (three sides in a row) within a short window. Glancing away and back is only one
// side, and looking left then right slowly is too slow, so neither counts. After a like, the head has to
// settle before the next shake can count, so one long shake is one like.
export class HeadShake {
  constructor({ windowMs = 1200, settleMs = 500, sides = 3 } = {}) {
    this.windowMs = windowMs; // all the sides must be reached within this window
    this.settleMs = settleMs; // after a like, the head must stay near the middle this long
    this.sides = sides;
    this.reset();
  }

  reset() {
    this.reached = [];   // times at which a new side was reached
    this.lastSide = 0;
    this.recent = [];    // the last few turn readings, to tell whether the head is moving
    this.spent = false;
    this.calmSince = 0;
  }

  // `turn` is how far the head is turned compared with rest; `need` is how far each way it must go.
  // Returns "like" once per shake, otherwise null.
  update(turn, now, need) {
    this.recent.push(turn);
    if (this.recent.length > 4) this.recent.shift();

    const side = turn > need ? 1 : turn < -need ? -1 : 0;
    if (side !== 0 && side !== this.lastSide) {
      this.reached.push(now);
      this.lastSide = side;
    }
    while (this.reached.length && now - this.reached[0] > this.windowMs) this.reached.shift();

    if (this.spent) {
      const calm = Math.abs(turn) < need && !this.moving(need);
      this.calmSince = calm ? (this.calmSince || now) : 0;
      if (!calm || now - this.calmSince < this.settleMs) return null;
      this.spent = false;
      this.reached = [];
      this.lastSide = 0;
    }

    if (this.reached.length < this.sides) return null;
    this.spent = true;
    this.calmSince = 0;
    return "like";
  }

  // True while the head is turning quickly, which also pulls the eyebrows around.
  moving(need) {
    return this.recent.length > 1 && Math.max(...this.recent) - Math.min(...this.recent) > need * 0.5;
  }
}
