// Clicking the toolbar icon opens the eye-browse window, or brings it forward if it is already open.
let controlWindowId = null;

chrome.action.onClicked.addListener(async () => {
  if (controlWindowId !== null) {
    try {
      await chrome.windows.update(controlWindowId, { focused: true });
      return;
    } catch {
      controlWindowId = null; // it was closed without us noticing
    }
  }
  const created = await chrome.windows.create({ url: "control.html", type: "popup", width: 340, height: 720 });
  controlWindowId = created.id;
});

chrome.windows.onRemoved.addListener(id => {
  if (id === controlWindowId) controlWindowId = null;
});
