# eye-browse 2.4

A Chrome extension that scrolls with your eyebrows and likes when you shake your head.

| Gesture | YouTube Shorts, Instagram Reels, TikTok, Facebook Reels | Any other page |
| --- | --- | --- |
| Raise eyebrows | Next video | Scroll down |
| Furrow eyebrows | Previous video | Scroll up |
| Shake your head side to side | Like | Nothing |

## Install (one time)
1. Install Node 18 or newer.
2. In this folder run `node setup.js`. It downloads the face-tracking files into `lib/`.
   If you already have a `lib` folder from an earlier version, copy it in instead.
3. Open `chrome://extensions`, turn on **Developer mode**, click **Load unpacked** and choose this folder.
   Remove any older eye-browse or BrowScroll entry first, then refresh any open video tabs.
4. Pin eye-browse to the toolbar.

## Use
1. Open youtube.com/shorts, instagram.com/reels, tiktok.com or facebook.com/reel and click into the tab once.
2. Click the eye-browse icon. A small window opens. Allow the camera.
3. Look at the screen with a neutral face for two seconds while it calibrates.
4. Click **Float on top**. The camera, status, Pause and Recalibrate move into a small window that stays
   above everything else. Leave the original window open behind it.
5. Click back on the video tab and use your face.

## Tuning
Open **Sensitivity** in the full window. Each gesture has a live bar and a slider; the tick on the bar is
the trigger point and the bar turns white when you cross it.

- Scrolls by accident: raise the Raise or Furrow threshold.
- Head shake not noticed: lower "Head shake". Likes by accident: raise it.

The **Back / Next / Like** test buttons send the same commands without using your face, to check a site responds.

## Good to know
- A shake is left, right and left again (or right, left, right) within about a second. Glancing to one side
  and back, or looking around slowly, does not count.
- Head turning is measured from how you sat during calibration, so recalibrate if you move your laptop.
- Eyebrows are ignored while you blink or shake your head, because both move them.
- If the status says "Can't reach this tab", refresh the video tab once. Browser pages (chrome://) and the
  Chrome Web Store can't be controlled by any extension.
- Liking needs you to be signed in on that site. On Instagram and Facebook it needs the English interface,
  because the button is found by its "Like" label.
- Floating needs Chrome 116 or newer. Closing the original window closes the floating one and stops tracking.
- All video is processed on your computer. Nothing is uploaded.

## How it works
- `tracker.js` runs the camera and Google's MediaPipe face model, and reports eyebrow and eye scores plus how
  far the head is turned, once per camera frame. It is driven by the browser's new-frame callback, with a
  backup clock (`ticker.js`) for when the window is covered, and it never spends more than half its time working.
- `gestures.js` decides when a gesture has happened: hold times, cooldowns, and the left-right-left shake.
- `control.html`, `control.css`, `control.js` are the window: status, settings, floating, and sending commands.
- `content.js` runs in the page and does the scrolling and liking for each site.
- `background.js` opens the window. `setup.js` downloads the face model.
