// Runs inside web pages. Carries out "next", "prev" and "like" commands from the eye-browse window.
(() => {
  // A copy of this script may already be in the page from before the extension was reloaded or updated.
  // That copy can no longer hear the extension, so this one takes its place rather than stepping aside.
  const previous = window.__eyeBrowse;
  if (previous?.listener) {
    try { chrome.runtime.onMessage.removeListener(previous.listener); } catch { /* it belonged to the old copy */ }
  }
  for (const id of ["eye-browse-style", "eye-browse-toast", "eye-browse-heart"]) document.getElementById(id)?.remove();

  const MESSAGE_TYPE = "eye-browse";

  /* ---------- on-page feedback: a small message and a heart ---------- */
  const style = document.createElement("style");
  style.id = "eye-browse-style";
  style.textContent = `
    #eye-browse-toast { position: fixed; left: 50%; top: 24px; transform: translate(-50%, -12px); opacity: 0;
      background: rgba(0, 0, 0, .92); color: #fff; font: 600 14px/1 system-ui, -apple-system, "Segoe UI", sans-serif;
      padding: 11px 18px; border-radius: 999px; border: 1px solid rgba(255, 255, 255, .35);
      box-shadow: 0 8px 28px rgba(0, 0, 0, .35); z-index: 2147483647; pointer-events: none;
      transition: opacity .2s, transform .2s; }
    #eye-browse-toast.show { opacity: 1; transform: translate(-50%, 0); }
    #eye-browse-heart { position: fixed; left: 50%; top: 50%; transform: translate(-50%, -50%) scale(0); opacity: 0;
      z-index: 2147483647; pointer-events: none; filter: drop-shadow(0 6px 24px rgba(0, 0, 0, .65)); }
    #eye-browse-heart.pop { animation: eye-browse-heart .8s ease-out; }
    @keyframes eye-browse-heart {
      0% { transform: translate(-50%, -50%) scale(0); opacity: 1; }
      30% { transform: translate(-50%, -50%) scale(1.2); opacity: 1; }
      60% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
      100% { transform: translate(-50%, -50%) scale(1.05); opacity: 0; }
    }`;
  const toast = document.createElement("div");
  toast.id = "eye-browse-toast";
  const heart = document.createElement("div");
  heart.id = "eye-browse-heart";
  heart.innerHTML = '<svg viewBox="0 0 24 24" width="150" height="150" aria-hidden="true"><path fill="#fff" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>';
  document.documentElement.append(style, toast, heart);

  let toastTimer;
  function showToast(text) {
    toast.textContent = text;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 1100);
  }
  function popHeart() {
    heart.classList.remove("pop");
    void heart.offsetWidth; // restart the animation
    heart.classList.add("pop");
  }

  /* ---------- helpers ---------- */
  const isVisible = el => el.getClientRects().length > 0 && !el.disabled;

  // True when the element's centre is on screen. Feeds keep neighbouring videos (and their buttons) in the
  // page just off screen, so "exists" is not enough to know a button belongs to the video being watched.
  function inViewport(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const x = (rect.left + rect.right) / 2, y = (rect.top + rect.bottom) / 2;
    return x >= 0 && x <= innerWidth && y >= 0 && y <= innerHeight;
  }
  function distanceFromMiddle(el) {
    const rect = el.getBoundingClientRect();
    return Math.abs((rect.top + rect.bottom) / 2 - innerHeight / 2);
  }
  const nearestToMiddle = elements => elements.reduce((best, el) => (!best || distanceFromMiddle(el) < distanceFromMiddle(best)) ? el : best, null);

  function clickFirstVisible(selectors) {
    for (const selector of selectors) {
      const el = [...document.querySelectorAll(selector)].find(isVisible);
      if (el) { el.click(); return true; }
    }
    return false;
  }

  function pressKey(key, keyCode) {
    const init = { key, code: key, keyCode, which: keyCode, bubbles: true, cancelable: true };
    document.dispatchEvent(new KeyboardEvent("keydown", init));
    document.dispatchEvent(new KeyboardEvent("keyup", init));
  }

  function scrollPage(direction) {
    window.scrollBy({ top: direction * innerHeight * 0.85, behavior: "smooth" });
  }

  // Full-size videos on the page, in page order (ignores thumbnails and previews).
  const feedVideos = () => [...document.querySelectorAll("video")].filter(v => v.getBoundingClientRect().height >= 100);

  function scrollParent(el) {
    for (let node = el?.parentElement; node; node = node.parentElement) {
      const overflowY = getComputedStyle(node).overflowY;
      if ((overflowY === "auto" || overflowY === "scroll") && node.scrollHeight > node.clientHeight + 1) return node;
    }
    return document.scrollingElement;
  }

  // Vertical video feeds scroll inside their own snapping container, so move to the neighbouring video.
  // If it isn't loaded yet, scroll the container by one screen instead.
  function stepVideoFeed(direction) {
    const videos = feedVideos();
    const current = nearestToMiddle(videos);
    const target = current ? videos[videos.indexOf(current) + direction] : null;
    if (target) {
      target.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    const scroller = scrollParent(current) || document.scrollingElement;
    scroller.scrollBy({ top: direction * scroller.clientHeight, behavior: "smooth" });
  }

  // Walks up from the video being watched to the smallest container holding a like control, then presses it.
  // `isLiked(control, button)` says whether the video is already liked, so a like is never undone.
  function likeNearVideo(selector, isLiked) {
    for (let node = nearestToMiddle(feedVideos()) || document.body; node; node = node.parentElement) {
      const control = [...node.querySelectorAll(selector)].find(inViewport);
      if (!control) continue;
      const button = control.closest('button, [role="button"]') || control;
      if (isLiked(control, button)) return "already";
      button.click();
      return "liked";
    }
    return "missing";
  }

  /* ---------- YouTube ---------- */
  // YouTube has shipped several like-button layouts, so match all of them and take the one on screen
  // nearest the middle. The label test ("like this video...") does not match "Dislike".
  const YOUTUBE_LIKE_BUTTONS = [
    "like-button-view-model button",
    "#like-button button",
    "#segmented-like-button button",
    'button[aria-label^="like this" i]',
  ].join(", ");

  function likeYouTube() {
    const all = [...document.querySelectorAll(YOUTUBE_LIKE_BUTTONS)];
    const button = nearestToMiddle(all.filter(inViewport)) || all.find(isVisible);
    if (!button) return "missing";
    if (button.getAttribute("aria-pressed") === "true") return "already";
    button.click();
    return "liked";
  }

  function stepShorts(direction) {
    const buttons = direction > 0
      ? ["#navigation-button-down button", "button[aria-label='Next video']"]
      : ["#navigation-button-up button", "button[aria-label='Previous video']"];
    if (clickFirstVisible(buttons)) return;
    if (direction > 0) pressKey("ArrowDown", 40); else pressKey("ArrowUp", 38);
  }

  /* ---------- Instagram, TikTok, Facebook (button labels are the English interface ones) ---------- */
  const likeInstagram = () => likeNearVideo(
    'svg[aria-label="Like"], svg[aria-label="Unlike"]',
    control => control.getAttribute("aria-label") === "Unlike");

  const likeTikTok = () => likeNearVideo(
    '[data-e2e="like-icon"], [data-e2e="browse-like-icon"]',
    (_control, button) => button.getAttribute("aria-pressed") === "true");

  const likeFacebook = () => likeNearVideo(
    '[aria-label="Like"], [aria-label="Remove Like"]',
    control => control.getAttribute("aria-label") === "Remove Like");

  function stepTikTok(direction) {
    // The single-video view has arrow buttons; the For You feed is a scrolling list.
    const arrow = direction > 0 ? 'button[data-e2e="arrow-right"]' : 'button[data-e2e="arrow-left"]';
    if (!clickFirstVisible([arrow])) stepVideoFeed(direction);
  }

  function stepFacebook(direction) {
    const card = direction > 0 ? '[aria-label="Next Card"]' : '[aria-label="Previous Card"]';
    if (!clickFirstVisible([card])) stepVideoFeed(direction);
  }

  /* ---------- which site are we on, and how it behaves ---------- */
  const SITES = {
    shorts:    { label: "YouTube Shorts",  step: stepShorts,    like: likeYouTube },
    youtube:   { label: "YouTube",         step: scrollPage,    like: likeYouTube },
    igReels:   { label: "Instagram Reels", step: stepVideoFeed, like: likeInstagram },
    instagram: { label: "Instagram",       step: scrollPage,    like: likeInstagram },
    tiktok:    { label: "TikTok",          step: stepTikTok,    like: likeTikTok },
    fbReels:   { label: "Facebook Reels",  step: stepFacebook,  like: likeFacebook },
    page:      { label: "Web page",        step: scrollPage,    like: () => "unsupported" },
  };

  function currentSite() {
    const host = location.hostname, path = location.pathname;
    const on = domain => host === domain || host.endsWith("." + domain);
    const isReelPath = /^\/reels?(\/|$)/.test(path);
    if (on("youtube.com")) return path.startsWith("/shorts") ? SITES.shorts : SITES.youtube;
    if (on("instagram.com")) return isReelPath ? SITES.igReels : SITES.instagram;
    if (on("tiktok.com")) return SITES.tiktok;
    if (on("facebook.com") && isReelPath) return SITES.fbReels;
    return SITES.page;
  }

  /* ---------- commands ---------- */
  const LIKE_MESSAGES = {
    liked: "Liked",
    already: "Already liked",
    missing: "Couldn't find the like button",
    unsupported: "Nothing to like on this site",
  };

  function run(action) {
    const site = currentSite();
    if (action === "next" || action === "prev") {
      site.step(action === "next" ? 1 : -1);
      showToast(action === "next" ? "Next" : "Back");
      return "ok";
    }
    if (action === "like") {
      const result = site.like();
      if (result === "liked" || result === "already") popHeart();
      showToast(LIKE_MESSAGES[result]);
      return result;
    }
    return "ok"; // "ping": just report where we are
  }

  function listener(message, _sender, reply) {
    if (message?.type !== MESSAGE_TYPE) return;
    const result = run(message.action);
    reply({ ok: true, result, site: currentSite().label, title: document.title });
  }
  chrome.runtime.onMessage.addListener(listener);
  window.__eyeBrowse = { listener };
})();
