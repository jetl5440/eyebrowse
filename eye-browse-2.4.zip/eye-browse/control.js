// The eye-browse window: shows the camera and status, turns readings from the face tracker into
// commands for the active browser tab, and can float above other windows.
import { createFaceTracker } from "./tracker.js";
import { Baseline, BrowScroll, HeadShake } from "./gestures.js";

const MESSAGE_TYPE = "eye-browse";
// shake: how far the head must turn each way (nose offset as a share of face width) for a shake to count.
const DEFAULTS = { up: 0.22, down: 0.22, shake: 0.1 };
const CALIBRATE_MS = 2000;    // time spent measuring the resting face
const FLASH_MS = 1200;        // how long a fired gesture stays in the status pill
const WARN_MS = 2500;         // how long a problem stays in the status pill
const PING_MS = 3000;         // how often the "Controlling" line is refreshed
const FLOAT_SIZE = { width: 240, height: 270 };

// Look every element up once. The controls can be moved into the floating window, which is a different
// document, so looking them up by id from this page later would not find them.
const elements = Object.fromEntries([...document.querySelectorAll("[id]")].map(el => [el.id, el]));
const $ = id => elements[id];

let paused = false;
let floating = false;

/* ---------- status pill ---------- */
let statusTimer;
function setStatus(text, tone, revertAfterMs) {
  clearTimeout(statusTimer);
  $("status").textContent = text;
  $("status").dataset.tone = tone;
  if (revertAfterMs) statusTimer = setTimeout(idleStatus, revertAfterMs);
}
function idleStatus() {
  if (baseline.active) setStatus("Look ahead, neutral face", "wait");
  else if (paused) setStatus("Paused", "wait");
  else setStatus("Tracking", "ok");
}

/* ---------- settings ---------- */
const settings = { ...DEFAULTS, ...(await chrome.storage.local.get(Object.keys(DEFAULTS))) };
const SLIDERS = [
  { key: "up", slider: "sUp", label: "lUp" },
  { key: "down", slider: "sDown", label: "lDown" },
  { key: "shake", slider: "sShake", label: "lShake" },
];
function showSettings() {
  for (const { key, slider, label } of SLIDERS) {
    $(slider).value = settings[key];
    $(label).textContent = settings[key].toFixed(2);
  }
  $("tUp").style.left = `calc(${settings.up * 100}% - 1px)`;
  $("tDown").style.left = `calc(${settings.down * 100}% - 1px)`;
  $("tShake").style.left = `calc(${Math.min(100, settings.shake * 250)}% - 1px)`; // the bar shows 0 to 0.4
}
for (const { key, slider } of SLIDERS) {
  $(slider).addEventListener("input", () => {
    settings[key] = Number($(slider).value);
    chrome.storage.local.set({ [key]: settings[key] });
    showSettings();
  });
}
$("reset").addEventListener("click", () => {
  Object.assign(settings, DEFAULTS);
  chrome.storage.local.set(DEFAULTS);
  showSettings();
});
showSettings();

/* ---------- talking to the page ---------- */
async function activeTab() {
  const win = await chrome.windows.getLastFocused({ windowTypes: ["normal"] });
  const [tab] = await chrome.tabs.query({ active: true, windowId: win.id });
  return tab;
}

// Sends a command to the active tab and returns the page's answer, or null if the page can't be reached.
async function send(action) {
  const message = { type: MESSAGE_TYPE, action };
  let tab;
  try { tab = await activeTab(); } catch { tab = null; }
  if (!tab) {
    $("target").textContent = "No browser tab found";
    return null;
  }

  let response;
  try {
    response = await chrome.tabs.sendMessage(tab.id, message);
  } catch {
    // No page script is listening: the tab was open before the extension was installed or reloaded.
    // Add a fresh copy (it replaces any stale one), then try again.
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      response = await chrome.tabs.sendMessage(tab.id, message);
    } catch {
      $("target").textContent = "Can't control this tab (browser or store page?)";
      return null;
    }
  }
  if (!response) return null;
  $("target").textContent = `${response.site} · ${response.title}`;
  return response;
}

const LIKE_PROBLEMS = {
  missing: "Like button not found",
  unsupported: "Nothing to like here",
};

async function fire(action, label) {
  setStatus(label, "fire", FLASH_MS);
  const response = await send(action);
  if (!response) setStatus("Can't reach this tab", "warn", WARN_MS);
  else if (action === "like" && LIKE_PROBLEMS[response.result]) setStatus(LIKE_PROBLEMS[response.result], "warn", WARN_MS);
}

/* ---------- gestures ---------- */
const baseline = new Baseline(CALIBRATE_MS);
const brows = new BrowScroll();
const shake = new HeadShake();
let rest = { up: 0, down: 0, turn: 0 };
let faceVisible = true;

function calibrate() {
  baseline.start(performance.now());
  brows.reset();
  shake.reset();
  idleStatus();
}

// The live bars are only drawn while someone can see them.
function showMeters(up, down, turn) {
  if (floating || !$("tuning").open) return;
  const draw = (name, value, limit, scale = 1) => {
    $("f" + name).style.width = Math.min(100, value * 100 * scale) + "%";
    $("f" + name).classList.toggle("over", value > limit);
  };
  draw("Up", up, settings.up);
  draw("Down", down, settings.down);
  draw("Shake", Math.abs(turn), settings.shake, 2.5);
}

// Called by the tracker once per camera frame.
function onReading(reading) {
  if (!reading.face) {
    if (faceVisible && !baseline.active) setStatus("No face in view", "warn");
    faceVisible = false;
    return;
  }
  if (!faceVisible) {
    faceVisible = true;
    idleStatus();
  }

  const now = reading.time;
  if (baseline.active) {
    if (baseline.add({ up: reading.up, down: reading.down, turn: reading.turn }, now)) {
      rest = baseline.values;
      idleStatus();
    }
    return;
  }

  const up = Math.max(0, reading.up - rest.up);
  const down = Math.max(0, reading.down - rest.down);
  const turn = reading.turn - rest.turn; // measured from how you normally sit
  showMeters(up, down, turn);
  if (paused) return;

  if (shake.update(turn, now, settings.shake) === "like") fire("like", "Head shake: like");
  if (reading.eyesShut || shake.moving(settings.shake)) {
    brows.block(now); // blinking and turning the head both pull the eyebrows around
    return;
  }
  const action = brows.update(up, down, settings, now);
  if (action === "next") fire("next", "Brows up: next");
  else if (action === "prev") fire("prev", "Brows down: back");
}

/* ---------- buttons ---------- */
$("recal").addEventListener("click", calibrate);
$("pause").addEventListener("click", () => {
  paused = !paused;
  $("pause").textContent = paused ? "Resume" : "Pause";
  $("pause").classList.toggle("active", paused);
  brows.reset();
  shake.reset();
  idleStatus();
});
$("testPrev").addEventListener("click", () => fire("prev", "Test: back"));
$("testNext").addEventListener("click", () => fire("next", "Test: next"));
$("testLike").addEventListener("click", () => fire("like", "Test: like"));

/* ---------- floating on top of other windows ---------- */
// Chrome's Document Picture-in-Picture window always stays above other windows. The controls are moved
// into it and moved back when it closes. It has to be opened straight from a click, with nothing awaited first.
const tracker = createFaceTracker($("cam"), onReading);

function dock() {
  floating = false;
  document.body.append($("ui"));
  $("parked").hidden = true;
  $("float").textContent = "Float on top";
  $("float").classList.add("primary");
  tracker.resume();
}

$("float").addEventListener("click", () => {
  if (!("documentPictureInPicture" in window)) {
    setStatus("Floating needs a newer Chrome", "warn", WARN_MS);
    return;
  }
  if (documentPictureInPicture.window) {
    documentPictureInPicture.window.close(); // its pagehide handler docks the controls
    return;
  }
  documentPictureInPicture.requestWindow(FLOAT_SIZE).then(pip => {
    const styles = pip.document.createElement("link");
    styles.rel = "stylesheet";
    styles.href = chrome.runtime.getURL("control.css");
    pip.document.head.append(styles);
    pip.document.title = "eye-browse";
    pip.document.body.classList.add("floating"); // switches on the compact layout in control.css
    pip.document.body.append($("ui"));
    pip.addEventListener("pagehide", dock, { once: true });
    floating = true;
    $("parked").hidden = false;
    $("float").textContent = "Stop floating";
    $("float").classList.remove("primary");
    tracker.resume(); // moving a video between windows can pause it
  }).catch(() => setStatus("Couldn't open floating window", "warn", WARN_MS));
});

/* ---------- start ---------- */
const START_PROBLEMS = {
  setup: "Run node setup.js first",
  camera: "Camera blocked",
  model: "Face model failed to load",
};
const STAGES = { camera: "Starting camera", model: "Loading face model" };

try {
  await tracker.start(stage => setStatus(STAGES[stage], "wait"));
  calibrate();
  send("ping");
  setInterval(() => send("ping"), PING_MS);
} catch (error) {
  setStatus(START_PROBLEMS[error.message] ?? "Couldn't start", "warn");
}
