// A steady clock. Timers inside a worker keep their pace even when the window that owns them is
// covered by another window, where ordinary page timers are slowed down.
onmessage = event => setInterval(() => postMessage(0), event.data);
