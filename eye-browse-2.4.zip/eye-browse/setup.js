// One-time setup: downloads the MediaPipe face-tracking files into ./lib.
// Chrome extensions may not load code from the internet, so these have to sit in the folder.
// Run with Node 18 or newer:   node setup.js
const fs = require("fs");
const path = require("path");

const VERSION = "0.10.14";
const CDN = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${VERSION}`;
const FILES = [
  [`${CDN}/vision_bundle.mjs`, "lib/vision_bundle.mjs"],
  [`${CDN}/wasm/vision_wasm_internal.js`, "lib/wasm/vision_wasm_internal.js"],
  [`${CDN}/wasm/vision_wasm_internal.wasm`, "lib/wasm/vision_wasm_internal.wasm"],
  [`${CDN}/wasm/vision_wasm_nosimd_internal.js`, "lib/wasm/vision_wasm_nosimd_internal.js"],
  [`${CDN}/wasm/vision_wasm_nosimd_internal.wasm`, "lib/wasm/vision_wasm_nosimd_internal.wasm"],
  ["https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task", "lib/face_landmarker.task"],
];

(async () => {
  for (const [url, relativePath] of FILES) {
    const target = path.join(__dirname, relativePath);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    process.stdout.write(`${relativePath} ... `);
    const response = await fetch(url);
    if (!response.ok) throw new Error(`${response.status} for ${url}`);
    fs.writeFileSync(target, Buffer.from(await response.arrayBuffer()));
    console.log("ok");
  }
  console.log("\nDone. Load this folder at chrome://extensions (Developer mode, then Load unpacked).");
})().catch(error => {
  console.error("\nFailed: " + error.message);
  process.exit(1);
});
