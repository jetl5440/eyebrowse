// Runs the camera and the face model, and reports one reading per camera frame.
// A reading is { face: false, time } or { face: true, time, up, down, eyesShut, turn }: `up` and `down` are
// raw eyebrow scores, and `turn` is how far the head is turned left or right (the nose's offset from the
// middle of the face, as a share of face width; the sign depends on direction).

const CAMERA = { width: 320, height: 240, facingMode: "user" }; // the model shrinks frames anyway; small is cheaper
const FRAME_MS = 50;            // at most 20 readings a second, which is plenty for these gestures
const CLOCK_MS = 50;            // how often the backup clock checks in
const STALL_MS = 150;           // no camera-frame callback for this long means the backup clock takes over
const REARM_MS = 1000;          // how often to re-request camera-frame callbacks while they are stalled
const EYES_SHUT_LEVEL = 0.5;    // blink score above which the eyes count as shut
const NOSE_TIP = 1, FACE_EDGE_A = 234, FACE_EDGE_B = 454;
const SHAPES = ["browInnerUp", "browOuterUpLeft", "browOuterUpRight", "browDownLeft", "browDownRight", "eyeBlinkLeft", "eyeBlinkRight"];

// `start()` rejects with an Error whose message is "setup", "camera" or "model", naming the step that failed.
export function createFaceTracker(video, onReading) {
  let landmarker = null;
  let shapeIndex = null;     // blendshape name -> position in the model's output, looked up once
  let nextFrameAt = 0;       // earliest time the next frame may be processed
  let lastVideoTime = -1;    // the camera frame processed last
  let lastCallbackAt = 0;    // when the browser last told us a new camera frame was shown
  let lastArmAt = 0;
  let callbackHandle = 0;

  /* ---------- one frame ---------- */
  function headTurn(landmarks) {
    const a = landmarks[FACE_EDGE_A].x, b = landmarks[FACE_EDGE_B].x;
    return (landmarks[NOSE_TIP].x - (a + b) / 2) / Math.max(0.01, Math.abs(b - a));
  }

  function read(time) {
    const result = landmarker.detectForVideo(video, time);
    const shapes = result.faceBlendshapes?.[0]?.categories;
    const landmarks = result.faceLandmarks?.[0];
    if (!shapes || !landmarks) return { face: false, time };

    if (!shapeIndex) {
      shapeIndex = {};
      shapes.forEach((shape, position) => { shapeIndex[shape.categoryName] = position; });
    }
    const score = name => shapes[shapeIndex[name]]?.score ?? 0;
    const [innerUp, outerUpLeft, outerUpRight, downLeft, downRight, blinkLeft, blinkRight] = SHAPES.map(score);
    return {
      face: true,
      time,
      up: Math.max(innerUp, (outerUpLeft + outerUpRight) / 2),
      down: (downLeft + downRight) / 2,
      eyesShut: Math.min(blinkLeft, blinkRight) > EYES_SHUT_LEVEL, // both eyes, so a wink doesn't count
      turn: headTurn(landmarks),
    };
  }

  // Processes the current camera frame if one is due and new. After each frame it waits at least twice
  // as long as the frame took, so the window always has spare time to draw and work never piles up.
  function process() {
    const started = performance.now();
    if (!landmarker || started < nextFrameAt || video.readyState < 2 || video.currentTime === lastVideoTime) return;
    lastVideoTime = video.currentTime;
    try {
      onReading(read(started));
    } catch (error) {
      console.error("eye-browse: frame failed", error); // one bad frame must not stop the next
    } finally {
      nextFrameAt = started + Math.max(FRAME_MS, (performance.now() - started) * 2);
    }
  }

  /* ---------- when to look at the camera ---------- */
  // Preferred: the browser calls us exactly when a new camera frame is shown, so nothing is polled.
  function arm() {
    if (!video.requestVideoFrameCallback) return;
    if (callbackHandle) video.cancelVideoFrameCallback(callbackHandle);
    lastArmAt = performance.now();
    callbackHandle = video.requestVideoFrameCallback(() => {
      callbackHandle = 0;
      lastCallbackAt = performance.now();
      process();
      arm();
    });
  }

  // Backup: those callbacks stop while the video isn't being drawn (window covered, or the video was just
  // moved to the floating window). A clock notices the silence, keeps frames flowing and re-requests them.
  function onClock() {
    const now = performance.now();
    if (now - lastCallbackAt < STALL_MS) return;
    process();
    if (now - lastArmAt > REARM_MS) arm();
  }

  function startClock() {
    try {
      const clock = new Worker(chrome.runtime.getURL("ticker.js"));
      clock.onmessage = onClock;
      clock.onerror = () => { clock.terminate(); setInterval(onClock, CLOCK_MS); };
      clock.postMessage(CLOCK_MS);
    } catch {
      setInterval(onClock, CLOCK_MS);
    }
  }

  async function start(onStage = () => {}) {
    let vision;
    try {
      vision = await import("./lib/vision_bundle.mjs");
    } catch {
      throw new Error("setup");
    }

    onStage("camera");
    try {
      video.srcObject = await navigator.mediaDevices.getUserMedia({ video: CAMERA });
    } catch {
      throw new Error("camera");
    }

    onStage("model");
    try {
      const files = await vision.FilesetResolver.forVisionTasks(chrome.runtime.getURL("lib/wasm"));
      const options = delegate => ({
        baseOptions: { modelAssetPath: chrome.runtime.getURL("lib/face_landmarker.task"), delegate },
        runningMode: "VIDEO",
        numFaces: 1,
        outputFaceBlendshapes: true,
      });
      try {
        landmarker = await vision.FaceLandmarker.createFromOptions(files, options("GPU"));
      } catch {
        landmarker = await vision.FaceLandmarker.createFromOptions(files, options("CPU"));
      }
    } catch {
      throw new Error("model");
    }

    arm();
    startClock();
  }

  // Call after moving the video to another window: restart playback and the frame callbacks.
  function resume() {
    video.play().catch(() => {});
    arm();
  }

  return { start, resume };
}
